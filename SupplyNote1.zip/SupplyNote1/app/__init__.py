from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager

app = Flask(__name__)
app.config.from_object('config.Config')

db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
# Avoid importing 'routes' directly in __init__.py
from app import routes

@login_manager.user_loader
def load_user(user_id):
    from app.models import User  # Import inside the function to avoid circular import
    return User.query.get(int(user_id))